#!/usr/bin/env python3
"""Payload box with an internal centre-of-mass offset, and optional preloading.

── 变体 A:内部质心偏移(2026-09-24)────────────────────────────────────────
导师当天问"现实中抓取为什么会有质心偏移"。此前所有批次的偏心都是**抓取位置**
偏的,原则上测一下抓在哪就能知道 c。本 world 让几何抓取完全对心,而把质心放在
箱子**内部**,于是:
  - 抓取几何完全对齐,
  - 任何对抓取点的测量都给不出这个偏移,
  - 飞机却仍然需要一个常值配平力矩。
这是"只能估、测不到"的干净证据,也是包裹内容物不居中的物理实况。
SDF 里用 <inertial> 自带的 <pose> 表达"同一个壳、内容物压在一端"。箱子自身
惯量取均匀长方体值,约占复合增量 mu*r_z^2 的 4%,已在质点近似声明之内。

── 预装载(--preloaded, 2026-09-24)──────────────────────────────────────
默认(抓取式)下箱子放在 (1.0, 0),无人机飞过去悬停在其上方约 0.5 m 吸附,吊臂
r_z ~ -0.5 m。预装载则把一个**扁平**箱子直接放在无人机出生点正下方,起飞前就
吸附,彻底没有接近/下降/抓取三段衔接。代价是吊臂缩到 ~ -0.2 m:
    dJ_xx = mu*(r_y^2 + r_z^2) 里 r_z^2 占 98%,故
    kappa = (Jxx+dJ)/Jxx 从 ~5.2 掉到 ~1.5(0.25 kg 载荷)。
★ 但一阶矩 s = m_P*r_xy 与配平力矩 tau = m_P*g*r_y **都不含 r_z**,所以变体 A
  要测的东西零损失;丢掉的是惯量增量那条叙事。用户 2026-09-24 明确接受该取舍。

几何:质心必须在箱内,故 y 向尺寸随偏移变长(SY = max(默认, 3*|COM_Y|))。
抓取式下 SZ 保持 0.15 使静止 pose 与夹爪 h_min/h_max 窗口不变;预装载下 SZ 取
扁平值,让箱子能塞进落地无人机的机腹与起落架之间。

Usage:
  make_offset_com_world.py SRC DST MASS COM_Y [--preloaded] [--size SX SY SZ]
                                              [--pose X Y]
"""
import argparse
import re
import sys

# 抓取式:立方体沿用历史尺寸;预装载:扁平,贴机腹
GRASP_DEFAULT = (0.15, 0.15, 0.15)
PRELOAD_DEFAULT = (0.24, 0.30, 0.06)
GRASP_POSE_XY = (1.0, 0.0)      # 历史抓取点
PRELOAD_POSE_XY = (0.0, 0.0)    # 无人机出生点正下方


def box_model(mass, com_y, sx, sy, sz, px, py):
    # 均匀长方体绕自身质心的惯量
    ixx = mass * (sy * sy + sz * sz) / 12.0
    iyy = mass * (sx * sx + sz * sz) / 12.0
    izz = mass * (sx * sx + sy * sy) / 12.0
    return f"""    <model name="box">
      <pose>{px} {py} {sz / 2.0:.4f} 0 0 0</pose>
      <link name="box_link">
        <inertial>
          <pose>0 {com_y:.4f} 0 0 0 0</pose>
          <mass>{mass}</mass>
          <inertia>
            <ixx>{ixx:.8f}</ixx><ixy>0</ixy><ixz>0</ixz>
            <iyy>{iyy:.8f}</iyy><iyz>0</iyz><izz>{izz:.8f}</izz>
          </inertia>
        </inertial>
        <visual name="visual">
          <geometry>
            <box><size>{sx:.4f} {sy:.4f} {sz:.4f}</size></box>
          </geometry>
          <material>
            <ambient>0.8 0.2 0.1 1</ambient>
            <diffuse>0.8 0.2 0.1 1</diffuse>
          </material>
        </visual>
        <collision name="collision">
          <geometry>
            <box><size>{sx:.4f} {sy:.4f} {sz:.4f}</size></box>
          </geometry>
        </collision>
      </link>
    </model>
"""


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument('src'), ap.add_argument('dst')
    ap.add_argument('mass', type=float), ap.add_argument('com_y', type=float)
    ap.add_argument('--preloaded', action='store_true')
    ap.add_argument('--size', nargs=3, type=float, metavar=('SX', 'SY', 'SZ'))
    ap.add_argument('--pose', nargs=2, type=float, metavar=('X', 'Y'))
    a = ap.parse_args()

    dsx, dsy, dsz = PRELOAD_DEFAULT if a.preloaded else GRASP_DEFAULT
    if a.size:
        sx, sy, sz = a.size
    else:
        # 质心必须留在箱内:y 向按偏移撑开
        sx, sy, sz = dsx, max(dsy, 3.0 * abs(a.com_y)), dsz
    px, py = a.pose if a.pose else (
        PRELOAD_POSE_XY if a.preloaded else GRASP_POSE_XY)

    # 落地时支撑多边形就是底面,质心跑到面外包裹会先自己倒掉
    if abs(a.com_y) >= 0.5 * sy:
        sys.exit(f'CoM offset {a.com_y} outside box half-width {0.5 * sy}')

    text = open(a.src).read()
    # 只替换 <model name="box"> 块:ground_plane 也有 <inertial>,
    # 任何按该标签注入的 sed 都会打错目标。
    pat = re.compile(r'[ \t]*<model name="box">.*?</model>\n', re.S)
    if not pat.search(text):
        sys.exit(f'no <model name="box"> block found in {a.src}')
    open(a.dst, 'w').write(
        pat.sub(box_model(a.mass, a.com_y, sx, sy, sz, px, py), text, count=1))
    print(f'[offset-com] box mass={a.mass} com_y={a.com_y} '
          f'size={sx:.4f}x{sy:.4f}x{sz:.4f} pose=({px},{py}) '
          f'{"PRELOADED" if a.preloaded else "grasp"} -> {a.dst}')


if __name__ == '__main__':
    main()
