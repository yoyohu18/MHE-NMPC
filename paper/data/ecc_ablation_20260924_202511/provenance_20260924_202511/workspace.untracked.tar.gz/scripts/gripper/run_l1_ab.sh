#!/bin/bash
# L1-NMPC 对照批次(2026-09-22):论文 §"Missing baselines" 点名的最大缺口。
#
# 论文原话:"Comparison nodes for the first two exist in the implementation but
# no frozen result set is reported for them. This is the largest gap in the
# evaluation." 本批就是去补那个 frozen result set。
#
# ── 两个臂(唯一差别 = NMPC_CONTROL_MODE)──────────────────────────────
#   A = mhe  主方法:MHE 显式估 m + 一阶矩 s,几何/内环都由估计驱动。
#   B = l1   流派 B(Hanover et al., RA-L 2021):**不估质量**,把变载荷当
#            lumped 平动扰动 d 在线估计并补进 NMPC 模型;模型侧 m/s/dJ 全部
#            锁在空机标称值。
#
# ── 为什么 B 臂也给内环补偿(D2(b),2026-07-23 用户拍板)────────────────
#   纯平动版实测 0.3kg/ecc0.10 姿态失稳(x/y d̂ 乱跳 = 内环带宽问题裸奔)。
#   不给增益就是绑着 baseline 的手打,审稿必疑。B 臂的内环补偿用载荷**包线
#   上界**(机架规格,非任务信息),不破坏"不知道精确质量"的设定。
#   ⚠️ 2026-09-22 修复:该补偿此前在 omega_scale 档下**静默失效**(互锁关掉了
#      PX4 参数路径,而 omega_scale 的 djest 源在 L1 档恒读到 dJ_est=0)。
#      现在两臂走**同一条** omega_scale 通路、同一套滤波/死区/headroom,
#      只有 dJ 来源不同(A=在线 dJ_est,B=包线常数)。日志里那行
#      "inner-loop: omega_scale(cmd) ... arm is NOT handicapped" 是自证。
#
# ⚠️ CONTINUOUS_PAYLOAD_ESTIMATES 必须是 false:_grip_mass_step 的 continuous
#    分支在 l1 分支**之前** return,开着就等于 B 臂拿不到 attach 内环补偿。
#    节点启动期会为这个组合打 error,批次侧也在下面再挡一道。
#
# ── 工况 ──────────────────────────────────────────────────────────────
#   W1 hover 0.15kg ecc0.00            ← 静态载荷:能不能把载荷"扛住"
#   W2 fig8 4m/s 0.15kg ecc0.10        ← 论文主工作点 r10/w0.283/z6/lift8.4
#   W3 fig8 4m/s 0.25kg ecc0.10        ← 重载(默认不跑,ONLY_W=W3 显式要)
#      用户 09-22 定 0.25 而非 0.30:仍在 0.3 包线内、κ≈4.4 不撞 cap 5.0,
#      配平力矩比 0.30kg 小约 17% —— 避开 09-14 坐实的 |r_y|≈0.17 时 roll
#      配平吃满 ±0.5N·m 致 figure-8 无余量那条已知坠机边界。
#
# 用法:
#   PAIRS=1 bash src/scripts/gripper/run_l1_ab.sh          # smoke(4 架次)
#   bash src/scripts/gripper/run_l1_ab.sh                  # 全量 W1+W2(32 架次)
#   ONLY_W=W2 PAIRS=8 bash .../run_l1_ab.sh                # 只跑主工作点
set -u

WS=/home/clear/ros2_ws_HJH
RES=$WS/nmpc_test_results
MAN=$RES/l1_ab_manifest.csv
LOCK=/tmp/l1_ab.lock
PAIRS=${PAIRS:-8}
ONLY_W=${ONLY_W:-"W1 W2"}
POST_SEC=${POST_SEC:-40}

# --- 跨工作区守卫:px4_sitl_default 是共享构建目录,他人的栈会互杀 ---
foreign=$(ps -eo pid,cmd | grep -E "bin/px4|make px4_sitl|ninja gz_x500|gz sim" \
          | grep -v grep | grep -v ugrep | grep -v "$WS")
if [ -n "$foreign" ]; then
  echo "[批次] 拒启:检测到非本工作区 px4/gz/make 在跑"; echo "$foreign" | cut -c1-100
  exit 2
fi

# 批次锁。⚠️ fd 9 必须在子进程里关掉(9>&-),否则孤儿子进程一直持锁且 ps 看不见。
exec 9>"$LOCK"
flock -n 9 || { echo "[批次] 另一个批次正持锁,退出"; exit 1; }

cleanup() {
  for pat in "run_gripper[_]headless.sh" "px4_sitl_default/bin/px4" "make px4_sitl" \
             "gz sim" "gz_bridge" "transport13/gz-transport-topic" \
             "ros_gz_bridge" "mavros/mavros_node" \
             "lib/offboard_test_acados/acados_nmpc_node" \
             "lib/offboard_test_acados/mhe_node" \
             "lib/offboard_test_acados/proximity_gripper_node" \
             "MicroXRCEAgent" "gcs_heartbeat"; do
    for pp in $(pgrep -f "$pat" 2>/dev/null); do kill -9 "$pp" 2>/dev/null || true; done
  done
  sleep 8
}
trap 'echo "[批次] 收到中断,清栈退出"; cleanup; exit 130' INT TERM

[ -f "$MAN" ] || echo "idx,wid,arm,stamp,started,finished,status" > "$MAN"

w_env() {
  case "$1" in
    W1) echo "GRIP_PAYLOAD_KG=0.15 GRIP_ECC_Y=0.0  GRIP_DYNAMIC=false GRIP_DROP_AFTER=15.0 GRIP_DROP_AT_TIP=false" ;;
    W2) echo "GRIP_PAYLOAD_KG=0.15 GRIP_ECC_Y=0.10 GRIP_DYNAMIC=true GRIP_DROP_AFTER=55.0 GRIP_DROP_AT_TIP=true GRIP_DYN_R=10.0 GRIP_DYN_W=0.283 GRIP_DYN_RAMP=9.36 GRIP_DYN_DZ=0.8 GRIP_Z_HIGH=6.0 GRIP_LIFT_DUR=8.4" ;;
    W3) echo "GRIP_PAYLOAD_KG=0.25 GRIP_ECC_Y=0.10 GRIP_DYNAMIC=true GRIP_DROP_AFTER=55.0 GRIP_DROP_AT_TIP=true GRIP_DYN_R=10.0 GRIP_DYN_W=0.283 GRIP_DYN_RAMP=9.36 GRIP_DYN_DZ=0.8 GRIP_Z_HIGH=6.0 GRIP_LIFT_DUR=8.4" ;;
  esac
}
w_truth() { case "$1" in W3) echo 0.25 ;; *) echo 0.15 ;; esac; }

# ---- 臂 env:唯一差别就是这一行 ----
arm_env() {
  if [ "$1" = "A" ]; then echo "NMPC_CONTROL_MODE=mhe"; else echo "NMPC_CONTROL_MODE=l1"; fi
}

# ---- 两臂逐字相同的公共 env ----
# CONTINUOUS=false + RELEASE_MODE=event:两臂的释放语义完全一致(都由 drop 指令
# 落地清模型),把"释放判据"这个因素整个移出本批 —— 本批只比控制性能。
# USE_MHE=true:B 臂的 NMPC 不消费 MHE 估计(节点内部旁路),但 MHE 照常运行,
# 两臂的 CPU 负载与话题时序才一致。
COMMON_ENV="USE_MHE=true CONTINUOUS_PAYLOAD_ESTIMATES=false \
NMPC_GEOM_SOURCE=online NMPC_GEOM_RELEASE_MODE=event \
NMPC_OMEGA_SCALE=true OMEGA_SCALE_SRC=djest \
MHE_C_XY_EST=true DJ_TRACK_MEST=true DJ_RATCHET=false \
GRIP_DJ_FLOOR_MP=0.05 GRIP_PAYLOAD_ENVELOPE=0.3 \
DROP_PUBLISH_MASS_EVENT=false MHE_SIGNAL_MODE=residual \
MHE_GEOM_COUPLED=1 MHE_GEOM_RELEASE_MODE=self \
L1_A_GAIN=10.0 L1_OMEGA_C=0.5 \
ATTACH_WINDOW_SEC=140.0"

run_one() {
  local wid="$1" arm="$2" idx="$3"
  local t0; t0=$(date +%FT%T)
  echo "[批次] === #$idx  $wid  arm=$arm($([ "$arm" = A ] && echo mhe || echo l1))  $(date +%T) ==="
  cleanup
  ls "$RES"/grip_nmpc_*.log 2>/dev/null | xargs -r -n1 basename > /tmp/.l1_ab_before

  # ⚠️ 9>&- 关掉继承的 flock fd
  setsid nohup env $COMMON_ENV $(w_env "$wid") $(arm_env "$arm") \
    EVAL_TRUE_PAYLOAD_MASS=$(w_truth "$wid") \
    bash "$WS/src/scripts/gripper/run_gripper_headless.sh" \
    > /tmp/l1_ab_cur.log 2>&1 9>&- &

  local N="" i
  for i in $(seq 1 72); do
    N=$(for f in "$RES"/grip_nmpc_*.log; do
          [ -e "$f" ] || continue
          grep -qxF "$(basename "$f")" /tmp/.l1_ab_before || echo "$f"
        done | sort | tail -1)
    [ -n "$N" ] && break
    sleep 5
  done
  if [ -z "$N" ]; then
    echo "[批次] !!! #$idx 六分钟没等到新日志,跳过"
    echo "$idx,$wid,$arm,NA,$t0,$(date +%FT%T),no-log" >> "$MAN"
    return
  fi
  local stamp; stamp=$(basename "$N" .log); stamp=${stamp#grip_nmpc_}
  echo "[批次] #$idx stamp=$stamp"

  # B 臂自证:内环补偿这一轮到底有没有生效(见文件头 D2(b))
  if [ "$arm" = "B" ]; then
    for i in $(seq 1 24); do
      grep -q "CONTROL MODE: l1" "$N" 2>/dev/null && break
      sleep 5
    done
    if grep -q "arm is NOT handicapped" "$N" 2>/dev/null; then
      echo "[批次] #$idx L1 内环补偿: OK"
    else
      echo "[批次] !!! #$idx L1 臂内环补偿未确认 —— 该轮不可用于对照"
      grep -E "inner-loop|control_mode=l1 与" "$N" 2>/dev/null | head -3
    fi
  fi

  local status="timeout"
  for i in $(seq 1 72); do
    grep -qE "DROP complete|DROP: released" "$N" 2>/dev/null && { status="ok"; break; }
    sleep 5
  done
  [ "$status" = "ok" ] && sleep "$POST_SEC"

  echo "$idx,$wid,$arm,$stamp,$t0,$(date +%FT%T),$status" >> "$MAN"
  echo "[批次] #$idx 结束: $status"
  cleanup
}

idx=0
for wid in $ONLY_W; do
  for r in $(seq 1 "$PAIRS"); do
    # 对内 ABBA/BAAB 交替,平衡"越跑越热"这类时间趋势
    if [ $((r % 2)) -eq 1 ]; then order="A B"; else order="B A"; fi
    for arm in $order; do
      idx=$((idx + 1))
      run_one "$wid" "$arm" "$idx"
    done
  done
done

cleanup
echo "[批次] 全部完成 $(date +%T) -> $MAN"
