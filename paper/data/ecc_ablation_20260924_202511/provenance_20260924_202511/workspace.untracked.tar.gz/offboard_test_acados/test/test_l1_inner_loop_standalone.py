#!/usr/bin/env python3
"""L1 对照臂的内环补偿通路(2026-09-22)。

背景:D2(b)(2026-07-23 用户拍板)要求 L1 对照臂用载荷**包线上界**(机架规格,
非任务信息)缩内环增益,否则"纯平动版 0.3kg/ecc0.10 姿态失稳"=绑着 baseline
的手打。那条路原先走 _scale_px4_rate_gains;内环补偿改成 omega_scale 后,
__init__ 的互锁会把 scale_px4_rate_gains 关掉,而 omega_scale 的 djest 源在
L1 档读到的 dJ_est 恒为 0 —— L1 臂内环补偿**静默归零**。

本文件锁住修复后的三件事:
  1. 主线(floor=0)逐位 no-op —— 修复不得改变主线任何一拍的 omega_scale;
  2. L1 档 attach 后 floor=包线 dJ,omega_scale 真的爬起来;
  3. 载荷没了以后 floor 撤掉,omega_scale 回落到 1。
外加 dJ 泄漏门控:L1 档模型侧不得消费 MHE 的 dJ。
"""

import numpy as np

from offboard_test_acados import acados_nmpc_node as an
from offboard_test_acados.acados_params import p
from offboard_test_acados.payload_estimate import PayloadEstimate

ENVELOPE = 0.3
ARM_D = 0.47


class _Stub:
    def __init__(self, control_mode='mhe'):
        self.now_sec = 0.0
        self.control_mode = control_mode
        self.grip_payload_envelope = ENVELOPE
        self.grip_arm_d = ARM_D
        self.omega_scale_enable = True
        self.omega_scale_source = 'djest'
        self.omega_scale_cap = 5.0
        self.omega_scale_hysteresis = 0.08
        self.omega_scale_tau = 0.5
        self.omega_scale_rise_rate = 4.0
        self.omega_scale_recover_rate = 1.5
        self.omega_scale = 1.0
        self._omega_scale_target = 1.0
        self._omega_scale_stamp = None
        self._omega_scale_dj_floor = 0.0
        self.dJ_est = 0.0
        self.m_est = p.m
        self.s_est = np.zeros(2)
        self.c_est = np.zeros(2)
        self._l1_T_phys = None

        # _update_continuous_payload_model 需要的一组
        self.payload_model_tau = 0.20
        self.payload_mass_slew = 0.60
        self.payload_moment_slew = 0.080
        self.payload_dj_slew = 0.080
        self.payload_estimate_fresh_sec = 0.35
        self._payload_estimate_received = True
        self._payload_estimate_rx_sec = 0.0
        self._payload_estimate_health_prev = None
        self._attach_j_bootstrap_active = False
        self._attach_j_bootstrap_weight = 0.0
        self._attach_j_bootstrap_dj = 0.0
        self._payload_target = PayloadEstimate(
            p.m, np.zeros(2), np.zeros(2), np.zeros(3),
            np.array([p.Jxx, p.Jyy, p.Jzz]), 1.0, True, 0.0)

    # c_xy 冻结不是本文件的被测对象,直通即可
    def _apply_cxy_freeze(self, c_live, _fresh):
        return c_live

    def _payload_estimate_is_fresh(self):
        return True

    def get_logger(self):
        class _Logger:
            info = warn = error = staticmethod(lambda _m: None)
        return _Logger()

    def get_clock(self):
        owner = self
        class _Now:
            @property
            def nanoseconds(self):
                return int(owner.now_sec * 1e9)
        class _Clock:
            @staticmethod
            def now():
                return _Now()
        return _Clock()


_Stub._dJ_from_mp = an.AcadosNMPCNode._dJ_from_mp
_update_omega = an.AcadosNMPCNode._update_omega_scale
_update_model = an.AcadosNMPCNode._update_continuous_payload_model


def _run(state, seconds):
    """推进 omega_scale 若干秒,返回逐拍轨迹。"""
    _update_omega(state)                 # 首拍只立时间戳
    trace = [state.omega_scale]
    for _ in range(round(seconds / p.dt)):
        state.now_sec += p.dt
        _update_omega(state)
        trace.append(state.omega_scale)
    return trace


def test_mainline_is_bit_identical():
    """floor 恒 0 时,新代码与"没有 floor"逐位相同——主线不受影响。"""
    ref = _Stub()
    ref.dJ_est = 0.040
    trace_new = _run(ref, 6.0)

    # 复刻旧行为:把 floor 这一项从算式里去掉(等价于改动前的代码)
    old = _Stub()
    old.dJ_est = 0.040
    old._omega_scale_dj_floor = float('-inf')   # max() 取不到它 = 旧算式
    trace_old = _run(old, 6.0)

    assert trace_new == trace_old, '主线 omega_scale 轨迹被改动影响了'
    assert trace_new[-1] > 1.5, f'基准轨迹没有爬起来(={trace_new[-1]:.3f}),测试无效'


def test_l1_floor_restores_inner_loop_compensation():
    """L1 档:dJ_est 恒 0,只有 floor 能把 omega_scale 顶起来。"""
    without = _Stub(control_mode='l1')
    assert _run(without, 6.0)[-1] == 1.0, 'L1 臂在没有 floor 时本应零补偿'

    withfloor = _Stub(control_mode='l1')
    withfloor._omega_scale_dj_floor = withfloor._dJ_from_mp(ENVELOPE)
    trace = _run(withfloor, 6.0)

    expected = (p.Jxx + withfloor._dJ_from_mp(ENVELOPE)) / p.Jxx
    assert expected > 4.0, f'包线 dJ 对应的惯量比 {expected:.2f} 与既有记录不符'
    assert abs(trace[-1] - min(expected, 5.0)) < 0.05, \
        f'omega_scale 没到位: {trace[-1]:.3f} vs {min(expected, 5.0):.3f}'
    assert all(b >= a - 1e-12 for a, b in zip(trace, trace[1:])), '爬升不单调'


def test_floor_release_returns_scale_to_one():
    """载荷没了 → floor 撤掉 → omega_scale 连续回落到 1(不是阶跃)。"""
    state = _Stub(control_mode='l1')
    state._omega_scale_dj_floor = state._dJ_from_mp(ENVELOPE)
    _run(state, 6.0)
    peak = state.omega_scale

    state._omega_scale_dj_floor = 0.0           # 三处复位点做的事
    trace = _run(state, 8.0)
    for a, b in zip(trace, trace[1:]):
        assert a - b <= state.omega_scale_recover_rate * p.dt + 1e-8, '回落超过限幅'
    assert peak > 4.0 and trace[-1] < 1.001, \
        f'没有回到 1: peak={peak:.3f} end={trace[-1]:.3f}'


def test_l1_model_side_never_consumes_mhe_inertia():
    """L1 档模型侧不得消费 MHE 的 dJ(dJ 由 m̂_p 代数生成 = 质量信息)。"""
    mhe_dj = 0.050
    loaded = PayloadEstimate(
        p.m + 0.3, np.array([0.03, 0.0]), np.array([0.01, 0.0]),
        np.array([mhe_dj, mhe_dj, 0.0]),                      # dJ_diag = 增量
        np.array([p.Jxx + mhe_dj, p.Jyy + mhe_dj, p.Jzz]),    # J_diag  = 绝对
        0.0, True, 0.0)

    l1 = _Stub(control_mode='l1')
    l1._payload_target = loaded
    for _ in range(round(3.0 / p.dt)):
        _update_model(l1)
    assert l1.dJ_est == 0.0, f'L1 臂吃到了 MHE 的 dJ: {l1.dJ_est:.4f}'
    assert l1.m_est == p.m, 'L1 臂吃到了 MHE 的质量'
    assert np.array_equal(l1.c_est, np.zeros(2)), 'L1 臂吃到了 MHE 的质心偏移'

    mhe = _Stub(control_mode='mhe')          # 对照:主线照吃不误
    mhe._payload_target = loaded
    for _ in range(round(3.0 / p.dt)):
        _update_model(mhe)
    assert mhe.dJ_est > 0.5 * mhe_dj, '主线的 dJ 通路被误伤'


if __name__ == '__main__':
    test_mainline_is_bit_identical()
    test_l1_floor_restores_inner_loop_compensation()
    test_floor_release_returns_scale_to_one()
    test_l1_model_side_never_consumes_mhe_inertia()
    print('all passed')
